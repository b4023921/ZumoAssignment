﻿namespace Zumo_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_forward = new System.Windows.Forms.Button();
            this.btn_right = new System.Windows.Forms.Button();
            this.btn_reverse = new System.Windows.Forms.Button();
            this.btn_left = new System.Windows.Forms.Button();
            this.btn_left90 = new System.Windows.Forms.Button();
            this.btn_right90 = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_stop_at_room = new System.Windows.Forms.Button();
            this.btn_scan_room = new System.Windows.Forms.Button();
            this.btn_AC = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_forward
            // 
            this.btn_forward.Location = new System.Drawing.Point(94, 28);
            this.btn_forward.Name = "btn_forward";
            this.btn_forward.Size = new System.Drawing.Size(75, 23);
            this.btn_forward.TabIndex = 0;
            this.btn_forward.Text = "forward";
            this.btn_forward.UseVisualStyleBackColor = true;
            this.btn_forward.Click += new System.EventHandler(this.btn_forward_Click);
            // 
            // btn_right
            // 
            this.btn_right.Location = new System.Drawing.Point(172, 73);
            this.btn_right.Name = "btn_right";
            this.btn_right.Size = new System.Drawing.Size(75, 23);
            this.btn_right.TabIndex = 1;
            this.btn_right.Text = "right";
            this.btn_right.UseVisualStyleBackColor = true;
            this.btn_right.Click += new System.EventHandler(this.btn_right_Click);
            // 
            // btn_reverse
            // 
            this.btn_reverse.Location = new System.Drawing.Point(94, 109);
            this.btn_reverse.Name = "btn_reverse";
            this.btn_reverse.Size = new System.Drawing.Size(75, 23);
            this.btn_reverse.TabIndex = 2;
            this.btn_reverse.Text = "reverse";
            this.btn_reverse.UseVisualStyleBackColor = true;
            this.btn_reverse.Click += new System.EventHandler(this.btn_reverse_Click_1);
            // 
            // btn_left
            // 
            this.btn_left.Cursor = System.Windows.Forms.Cursors.PanWest;
            this.btn_left.Location = new System.Drawing.Point(12, 73);
            this.btn_left.Name = "btn_left";
            this.btn_left.Size = new System.Drawing.Size(75, 23);
            this.btn_left.TabIndex = 3;
            this.btn_left.Text = "left";
            this.btn_left.UseVisualStyleBackColor = true;
            this.btn_left.Click += new System.EventHandler(this.btn_left_Click);
            // 
            // btn_left90
            // 
            this.btn_left90.Location = new System.Drawing.Point(12, 156);
            this.btn_left90.Name = "btn_left90";
            this.btn_left90.Size = new System.Drawing.Size(75, 23);
            this.btn_left90.TabIndex = 4;
            this.btn_left90.Text = "left (90)";
            this.btn_left90.UseVisualStyleBackColor = true;
            this.btn_left90.Click += new System.EventHandler(this.btn_left90_Click);
            // 
            // btn_right90
            // 
            this.btn_right90.Location = new System.Drawing.Point(172, 156);
            this.btn_right90.Name = "btn_right90";
            this.btn_right90.Size = new System.Drawing.Size(75, 23);
            this.btn_right90.TabIndex = 5;
            this.btn_right90.Text = "right(90)";
            this.btn_right90.UseVisualStyleBackColor = true;
            this.btn_right90.Click += new System.EventHandler(this.btn_right90_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(94, 73);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(75, 23);
            this.btn_stop.TabIndex = 6;
            this.btn_stop.Text = "stop";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // btn_stop_at_room
            // 
            this.btn_stop_at_room.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_stop_at_room.Location = new System.Drawing.Point(49, 219);
            this.btn_stop_at_room.Name = "btn_stop_at_room";
            this.btn_stop_at_room.Size = new System.Drawing.Size(172, 23);
            this.btn_stop_at_room.TabIndex = 7;
            this.btn_stop_at_room.Text = "stop at room";
            this.btn_stop_at_room.UseVisualStyleBackColor = false;
            this.btn_stop_at_room.Click += new System.EventHandler(this.btn_stop_at_room_Click);
            // 
            // btn_scan_room
            // 
            this.btn_scan_room.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_scan_room.Location = new System.Drawing.Point(49, 263);
            this.btn_scan_room.Name = "btn_scan_room";
            this.btn_scan_room.Size = new System.Drawing.Size(172, 23);
            this.btn_scan_room.TabIndex = 8;
            this.btn_scan_room.Text = "scan room";
            this.btn_scan_room.UseVisualStyleBackColor = false;
            this.btn_scan_room.Click += new System.EventHandler(this.btn_scan_room_Click);
            // 
            // btn_AC
            // 
            this.btn_AC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_AC.Location = new System.Drawing.Point(49, 309);
            this.btn_AC.Name = "btn_AC";
            this.btn_AC.Size = new System.Drawing.Size(172, 23);
            this.btn_AC.TabIndex = 10;
            this.btn_AC.Text = "Autonomous Control";
            this.btn_AC.UseVisualStyleBackColor = false;
            this.btn_AC.Click += new System.EventHandler(this.btn_AC_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(392, 74);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(154, 21);
            this.comboBox1.TabIndex = 11;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(392, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Select Port";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(392, 101);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(154, 160);
            this.listBox1.TabIndex = 13;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.Location = new System.Drawing.Point(395, 267);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Calibrate";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 334);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btn_AC);
            this.Controls.Add(this.btn_scan_room);
            this.Controls.Add(this.btn_stop_at_room);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_right90);
            this.Controls.Add(this.btn_left90);
            this.Controls.Add(this.btn_left);
            this.Controls.Add(this.btn_reverse);
            this.Controls.Add(this.btn_right);
            this.Controls.Add(this.btn_forward);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_forward;
        private System.Windows.Forms.Button btn_right;
        private System.Windows.Forms.Button btn_reverse;
        private System.Windows.Forms.Button btn_left;
        private System.Windows.Forms.Button btn_left90;
        private System.Windows.Forms.Button btn_right90;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_stop_at_room;
        private System.Windows.Forms.Button btn_scan_room;
        private System.Windows.Forms.Button btn_AC;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
    }
}

