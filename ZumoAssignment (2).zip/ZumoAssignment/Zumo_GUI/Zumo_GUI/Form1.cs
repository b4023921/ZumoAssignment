﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace Zumo_GUI
{
    public partial class Form1 : Form
    {
        SerialPort port;
        string labelContents = "    ";
        string newMessage = " ";
        string oldMessage = " ";
        // private Object dummy = new object(); // needed if there are any thread-safety issues accessing the labelContents variable
        public Form1()
        {
            InitializeComponent();
            // SerialPort.GetPortNames();
            List<string> data = new List<string>();
            data.Add(" ");
            comboBox1.DataSource = data.Concat(SerialPort.GetPortNames()).ToList();
            btn_forward.Enabled = false;
         //   btn_reverse.Enabled = false;
        }

        private string LabelContents
        {
            get
            {
                //lock (dummy) { // make it thread safe
                return labelContents; //}
            }
            set
            {
                //lock (dummy) { // make it thread safe
                labelContents = value;// }
            }
        }

        private void btn_forward_Click(object sender, EventArgs e)
        {
            // port.Open();
            port.Write("w");
            // port.Close();
        }

        private void btn_reverse_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("s");
            // port.Close();
        }

        private void DataReceivedHandler(
                    object sender,
                    SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadLine();

            LabelContents = "Data Received:" + indata; // this event handler runs in a separate thread to the GUI, so might need the thread safety protections...
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            port.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = LabelContents;  // update the contents of the text box...
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string portName = (string)comboBox1.SelectedItem;
            try
            {
                port.Close(); // should probably also tidy up the event handler and dispose of the port object 
            }
            catch (Exception err)
            {
                LabelContents = "not connected yet ";
            }
            btn_forward.Enabled = false;
         //   btn_reverse.Enabled = false;
            try
            {
                port = new SerialPort(portName, 9600);
                LabelContents = "connected to " + portName;
                port.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                port.Open();
                btn_forward.Enabled = true;

              //  if (port.available() > 0)
             //   btn_reverse.Enabled = true;
            }
            catch (Exception err)
            {
                LabelContents = "not connected yet ";
            }
        }

        private void btn_left_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("a");
            // port.Close();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("p");
            // port.Close();
        }

        private void btn_right_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("d");
            // port.Close();
        }

        private void btn_left90_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("l");
            // port.Close();
        }

        private void btn_right90_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("r");
            // port.Close();
        }

        private void btn_stop_at_room_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("t");
            // port.Close();
        }

        private void btn_scan_room_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("f");
            // port.Close();
        }

        private void btn_AC_Click(object sender, EventArgs e)
        {
            //  port.Open();
            port.Write("c");
            // port.Close();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_reverse_Click_1(object sender, EventArgs e)
        {
            port.Write("s");

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadLine();

            LabelContents = "Data Received:" + indata;

            port.ReadTo(LabelContents);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            port.Write("k");
        }
    }
}
